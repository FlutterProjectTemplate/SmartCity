#import <Flutter/Flutter.h>

@interface TextToSpeechPlugin : NSObject<FlutterPlugin>
@end
