## 0.2.3

* Migrate to Platform Interface

## 0.1.1

* Fix macOS issue

## 0.1.0

* Initial release: Android, iOS, web, and macOS API support