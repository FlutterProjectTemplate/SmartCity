//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import text_to_speech_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  TextToSpeechMacOsPlugin.register(with: registry.registrar(forPlugin: "TextToSpeechMacOsPlugin"))
}
