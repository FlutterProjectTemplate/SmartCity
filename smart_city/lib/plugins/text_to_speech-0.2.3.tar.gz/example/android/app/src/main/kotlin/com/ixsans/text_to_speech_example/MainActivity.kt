package com.ixsans.text_to_speech_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
